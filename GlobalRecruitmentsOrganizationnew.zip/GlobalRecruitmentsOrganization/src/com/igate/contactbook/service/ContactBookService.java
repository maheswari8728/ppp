package com.igate.contactbook.service;

import com.igate.contactbook.Exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public interface ContactBookService {
	
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException;
	public EnquiryBean getEnquiryDetails(int enquiryID) throws ContactBookException;
	public boolean isValidEnquiry(EnquiryBean enqry) throws ContactBookException;
	

}
