package com.igate.contactbook.service;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.igate.contactbook.Exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookServiceImpl implements ContactBookService{

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public EnquiryBean getEnquiryDetails(int enquiryID) throws ContactBookException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry) throws ContactBookException {
		// TODO Auto-generated method stub
		return false;
	}

	public void validateEnquiryBean(EnquiryBean enqry) {
		
		List<String> validationErrors=new ArrayList<String>();
		
		
		if(!(isValidfName(enqry.getfName()))) {
		    validationErrors.add("Name should start with captial letter and should have a minimum length of 3 characters\n");
		    }
		if(!(isValidlName(enqry.getlName()))) {
			validationErrors.add("Name should start with captial letter and should have a minimum length of 3 characters\n");
		    }
		
		if(!(isValidcontactNumber(enqry.getContactNo()))) {
			validationErrors.add("should have minimum 10 digits and should be a positive number\n");
			}
		
		if(!(isValidpDomain(enqry.getpDomain()))) {
			validationErrors.add("Name should start with captial letter and should have a minimum length of 3 characters\n");
			}
		
		if(!(isValidpLocation(enqry.getpLocation()))) {
			validationErrors.add("Name should start with capital letter an dshould have a min length of 3 characters\n");			
		}
	

}

	private boolean isValidpLocation(String pLocation) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(pLocation);
		return nameMatcher.matches();
	}

	private boolean isValidpDomain(String pDomain) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(pDomain);
		return nameMatcher.matches();
		
	}

	private boolean isValidcontactNumber(String contactNo) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(contactNo);
		return nameMatcher.matches();
	}

	private boolean isValidfName(String fName) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(fName);
		return nameMatcher.matches();
	}
	private boolean isValidlName(String lName) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(lName);
		return nameMatcher.matches();
	}
}