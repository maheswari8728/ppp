package com.igate.contactbook.Exception;

public class ContactBookException extends Exception {

}
