package com.igate.contactbook.dao;

import com.igate.contactbook.Exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImpl implements ContactBookDao{

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException {
		// TODO Auto-generated method stub
		return null;
	}

}
