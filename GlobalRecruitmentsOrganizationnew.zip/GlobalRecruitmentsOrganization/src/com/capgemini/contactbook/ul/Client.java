package com.capgemini.contactbook.ul;

import java.util.Scanner;

import com.igate.contactbook.Exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;
import com.igate.contactbook.service.ContactBookService;
import com.igate.contactbook.service.ContactBookServiceImpl;

public class Client {
	
	 static Scanner sc=new Scanner(System.in);
	 static ContactBookService contactBookService=null;
	 static ContactBookServiceImpl contactBookServiceImpl=null;
	 
	public static void main(String args[])
	{
		EnquiryBean enqry=null;
		int EnquiryId=null;
		int ch=0;
		
		try {
			
		   do {
			System.out.println("*******************Global Recruitments****************\n");
			System.out.println("choose an option\n");
			System.out.println("1.Enter Enquiry Details\n");
			System.out.println("2.View Enquiry Details on Id\n");
			System.out.println("0.Exit\n");
			System.out.println("**********************************\n");
			System.out.println("Please enter a choice:\n");
			ch=sc.nextInt();
			System.out.println("***************************************\n");
			switch(ch)
			{
			case 1: while(enqry==null) {
				    enqry=populateEnquiryBean();
			         }
			try {
			        contactBookService=new ContactBookServiceImpl();
			        EnquiryId=contactBookService.addEnquiry(enqry);
				    
			}  
			catch(ContactBookException contactBookException) {
				
			}
			}
			
		}
		
		}
		catch(Exception e) {
			
		}
	}

	private static EnquiryBean populateEnquiryBean() {
		
		EnquiryBean enqry=new EnquiryBean();
		
		System.out.println("Enter the First Name:");
		enqry.setfName(sc.next());
		System.out.println("Enter the Last Name:");
		enqry.setlName(sc.next());
		System.out.println("Enter Contact Number:");
		enqry.setContactNo(sc.next());
		System.out.println("Enter Preffered Domain:");
		enqry.setpDomain(sc.next());
		System.out.println("Enter Preferred Location:");
		enqry.setpLocation(sc.next());
		
		contactBookServiceImpl=new ContactBookServiceImpl();
		try {
			contactBookServiceImpl.validateEnquiryBean(enqry);
			return enqry;
		}
		catch (Exception contactBookException) {
			System.err.println("Invalid data");
			System.err.println(contactBookException.getMessage() + "\n try again");
			System.exit(0);
		}
		
		return enqry;

}
}
